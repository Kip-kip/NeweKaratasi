package com.ekaratasi.POJO;

/**
 * Created by Cyrus on 8/20/2017.
 */

public class MainData {

    String user_id,docfile,material,bindoption,bindcolor,copies,agent,instructions,error_msg,error;


    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getDocfile() {
        return docfile;
    }

    public void setDocfile(String docfile) {
        this.docfile = docfile;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }


    public String getBindoption() {
        return bindoption;
    }

    public void setBindoption(String bindoption) {
        this.bindoption = bindoption;
    }

    public String getBindcolor() {
        return bindcolor;
    }

    public void setBindcolor(String bindcolor) {
        this.bindcolor = bindcolor;
    }

    public String getCopies() {
        return copies;
    }

    public void setCopies(String copies) {
        this.copies = copies;
    }

    public String getAgent() {
        return agent;
    }

    public void setAgent(String agent) {
        this.agent = agent;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public String getError_msg() {
        return error_msg;
    }

    public void setError_msg(String error_msg) {
        this.error_msg = error_msg;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
