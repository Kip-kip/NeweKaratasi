package com.ekaratasi.POJO;

/**
 * Created by Cyrus on 8/29/2017.
 */

public class UserLogin {
    String emaili,passi,error_msg,error,returnphone,returnname,returnuserid,returnemail;


    public String getEmaili() {
        return emaili;
    }

    public void setEmaili(String emaili) {
        this.emaili = emaili;
    }

    public String getPassi() {
        return passi;
    }

    public void setPassi(String passi) {
        this.passi = passi;
    }

    public String getError_msg() {
        return error_msg;
    }

    public void setError_msg(String error_msg) {
        this.error_msg = error_msg;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getReturnphone() {
        return returnphone;
    }

    public void setReturnphone(String returnphone) {
        this.returnphone = returnphone;
    }

    public String getReturnname() {
        return returnname;
    }

    public void setReturnname(String returnname) {
        this.returnname = returnname;
    }

    public String getReturnuserid() {
        return returnuserid;
    }

    public void setReturnuserid(String returnuserid) {
        this.returnuserid = returnuserid;
    }

    public String getReturnemail() {
        return returnemail;
    }

    public void setReturnemail(String returnemail) {
        this.returnemail = returnemail;
    }
}
