package com.ekaratasi.POJO;

/**
 * Created by Cyrus on 8/29/2017.
 */

public class ConfirmAgent {
    String agentrefno,error_msg,error,returnagentname;

    public String getAgentrefno() {
        return agentrefno;
    }

    public void setAgentrefno(String agentrefno) {
        this.agentrefno = agentrefno;
    }

    public String getError_msg() {
        return error_msg;
    }

    public void setError_msg(String error_msg) {
        this.error_msg = error_msg;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getReturnagentname() {
        return returnagentname;
    }

    public void setReturnagentname(String returnagentname) {
        this.returnagentname = returnagentname;
    }
}
