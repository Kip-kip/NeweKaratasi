package com.ekaratasi.POJO;

/**
 * Created by Cyrus on 8/29/2017.
 */

public class ForgotPin {
    String email,error_msg,error;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getError_msg() {
        return error_msg;
    }

    public void setError_msg(String error_msg) {
        this.error_msg = error_msg;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
