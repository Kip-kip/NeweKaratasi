package com.ekaratasi.POJO;

/**
 * Created by Cyrus on 8/29/2017.
 */

public class UserPay {
    String phone,cash;
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getCash() {
        return cash;
    }

    public void setCash(String cash) {
        this.cash = cash;
    }


}
