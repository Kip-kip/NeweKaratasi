package com.ekaratasi.POJO;

/**
 * Created by Cyrus on 8/29/2017.
 */

public class ReadMessage {
    String agentt,customer,error_msg,error;

    public String getAgentt() {
        return agentt;
    }

    public void setAgentt(String agentt) {
        this.agentt = agentt;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getError_msg() {
        return error_msg;
    }

    public void setError_msg(String error_msg) {
        this.error_msg = error_msg;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
